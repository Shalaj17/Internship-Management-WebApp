package com.mvc.bean;

public class StudByDeptBean {
	private String id;
	private String name;
	private String uni_id;
	private String dept_name;
	private int cpi;
	
	public StudByDeptBean() {
		
	}
	public StudByDeptBean(String id, String name, String uni_id, String dept_name, int cpi) {
		this.id=id;
		this.name=name;
		this.uni_id=uni_id;
		this.dept_name=dept_name;
		this.cpi=cpi;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getUniId() {
		return uni_id;
	}
	public void setUniId(String uni_id) {
		this.uni_id = uni_id;
	}
	
	
	public String getDeptName() {
		return dept_name;
	}
	public void setDeptName(String dept_name) {
		this.dept_name = dept_name;
	}
	
	
	public int getCpi() {
		return cpi;
	}
	public void setCpi(int cpi) {
		this.cpi = cpi;
	}
}
