package com.mvc.bean;

//import com.sun.org.apache.regexp.internal.recompile;

public class UniByRankBean {
	private String university_id;
	private String university_name;
	private String type;
	private int university_rank;
	private String email;
	private int Location_pin;
	
	public UniByRankBean() {
		
	}
	public UniByRankBean(String university_id, String university_name, String type, int university_rank,int Location_pin, String email) {
		this.university_id=university_id;
		this.university_name=university_name;
		this.type=type;
		this.university_rank=university_rank;
		this.email=email;
		this.Location_pin = Location_pin;
	}
	
	public String getUniId() {
		return university_id;
	}
	public void setUniId(String university_id) {
		this.university_id = university_id;
	}
	public String getUniName() {
		return university_name;
	}
	public void setUniName(String university_name) {
		this.university_name=university_name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type= type;
	}
	public int getUniRank() {
		return university_rank;
	}
	public void setUniRank(int university_rank) {
		this.university_rank= university_rank;
	}
	public int getLocationPin() {
		return Location_pin;
	}
	public void setLocationPin(int Location_pin) {
		this.Location_pin= Location_pin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email=email;
	}
}
