package com.mvc.bean;

public class AddJobBean {
	
	private String project_id;
	private String intern_profile;
	private String duration;
	private String stipend;
	
	public String getProjectId() {
		return project_id;
		}
	public void setProjectId(String project_id) {
		this.project_id = project_id;
		}
	
	public String getInternProfile() {
		return intern_profile;
		}
	public void setInternProfile(String intern_profile) {
		this.intern_profile = intern_profile;
		}
	
	public String getDuration() {
		return duration;
		}
	public void setDuration(String duration) {
		this.duration = duration;
		}
	
	public String getStipend() {
		return stipend;
		}
	public void setStipend(String stipend) {
		this.stipend = stipend;
		}
}
