package com.mvc.bean;

public class JobDetails {
	
	
	
	String jobId;
	String jobProfile;
	String jobDuration;
	String jobStipend;
	
	public String getjobId() {
		return jobId;
	}
	public void setjobId(String jobId) {
		this.jobId = jobId;
	}
	public String getjobProfile() {
		return jobProfile;
	}
	public void setjobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}
	public String getjobDuration() {
		return jobDuration;
	}
	public void setjobDuration(String jobDuration) {
		this.jobDuration = jobDuration;
	}
	public String getjobStipend() {
		return jobStipend;
	}
	public void setjobStipend(String jobStipend) {
		this.jobStipend = jobStipend;
	}


}
