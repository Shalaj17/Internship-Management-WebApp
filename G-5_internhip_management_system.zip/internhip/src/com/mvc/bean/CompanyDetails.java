package com.mvc.bean;


public class CompanyDetails {


		
		String companyId;
		String companyName;
		String companyEmail;
		String companyPhone;
		String companyLocationpin;
		
		public String getcompanyId() {
			return companyId;
		}
		public void setcompanyId(String companyId) {
			this.companyId = companyId;
		}
		public String getcompanyName() {
			return companyName;
		}
		public void setcompanyName(String companyName) {
			this.companyName = companyName;
		}
		public String getcompanyEmail() {
			return companyEmail;
		}
		public void setcompanyEmail(String companyEmail) {
			this.companyEmail = companyEmail;
		}
		public String getcompanyPhone() {
			return companyPhone;
		}
		public void setcompanyPhone(String companyPhone) {
			this.companyPhone = companyPhone;
		}
		public String getcompanyLocationpin() {
			return companyLocationpin;
		}
		public void setcompanyLocationpin(String companyLocationpin) {
			this.companyLocationpin = companyLocationpin;
		}
		


	
}
