package com.mvc.bean;

public class UniLocBean {
	private String university_id;
	private String university_name;
	private int university_rank;
	private String email;
	
	public UniLocBean() {
		// TODO Auto-generated constructor stub
	}
	public UniLocBean(String university_id, String university_name, int university_rank, String email) {
		this.university_id=university_id;
		this.university_name=university_name;
		this.university_rank=university_rank;
		this.email=email;
	}
	public String getUniId() {
		return university_id;
	}
	public void setUniId(String university_id) {
		this.university_id = university_id;
	}
	public String getUniName() {
		return university_name;
	}
	public void setUniName(String university_name) {
		this.university_name=university_name;
	}
	
	public int getUniRank() {
		return university_rank;
	}
	public void setUniRank(int university_rank) {
		this.university_rank= university_rank;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email=email;
	}
}