package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.mvc.bean.CompanyNewLoginBean;
import com.mvc.dao.CompanyNewLoginDao;
 

public class CompanyNewLoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CompanyNewLoginServlet() {
	 }
	
		
		protected void doPost (HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException 
		{
			 
			//Here username and password are the names which I have given in the input box in Login.jsp page. Here I am retrieving the values entered by the user and keeping in instance variables for further use.
			 
			 String userName = request.getParameter("id");
			 String password = request.getParameter("pwd");
			 String name = request.getParameter("companyname");
			 String email = request.getParameter("email");
			 String phone = request.getParameter("phonenumber");
			 String city = request.getParameter("city");
			 String state = request.getParameter("state");
			 String pincode = request.getParameter("pincode");
			 
			 
			 
			 
			 System.out.println("pincode is "+pincode);
			 
			CompanyNewLoginBean companyNewLoginBean = new CompanyNewLoginBean(); //creating object for LoginBean class, which is a normal java class, contains just setters and getters. Bean classes are efficiently used in java to access user information wherever required in the application.
			 
			companyNewLoginBean.setUserName(userName); //setting the username and password through the loginBean object then only you can get it in future.
			companyNewLoginBean.setPassword(password);
			companyNewLoginBean.setName(name);
			companyNewLoginBean.setEmail(email);
			companyNewLoginBean.setPhone(phone);
			companyNewLoginBean.setCity(city);
			companyNewLoginBean.setState(state);
			companyNewLoginBean.setPincode(pincode);
			
			
			CompanyNewLoginDao companyNewLoginDao = new CompanyNewLoginDao(); //creating object for LoginDao. This class contains main logic of the application.
			 
			String addcaccount = companyNewLoginDao.addcaccount(companyNewLoginBean); //Calling authenticateUser function
			//studentNewLoginDao.addsaccount(studentNewLoginBean);
			if(addcaccount.equals("SUCCESS")) //If function returns success string then user will be rooted to Home page
			 {
			 request.setAttribute("userName", userName); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
			 request.getRequestDispatcher("/companynewaccount.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
			 }
			 else
			 {
				 System.out.println("not added succdesfully");
			 request.setAttribute("errMessage", addcaccount);
			 //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
			 request.getRequestDispatcher("/CompSignUp.jsp").forward(request, response);//forwarding the request
			 }
			 }
		
	 

}
