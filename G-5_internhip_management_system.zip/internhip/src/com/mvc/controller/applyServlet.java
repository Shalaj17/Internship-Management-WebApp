package com.mvc.controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class applyServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public applyServlet() {} //Initialization

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String Suser = request.getParameter("Suser");
		System.out.println("user in (applyservlet)  "+Suser);
		
		String company_id = request.getParameter("company_id");
		System.out.println("Cuer in (applyservlet)  "+company_id);
		
		Connection connection=null;
		
		try {
			
			connection = DBConnection.createConnection();
			 PreparedStatement pstmt3 = connection.prepareStatement("insert into apply values(?,?)");
			 
			 System.out.println(pstmt3);
			 
			  pstmt3.setString(1,Suser); 
			  pstmt3.setString(2, company_id);
 
			  pstmt3.executeUpdate();
			  
			  System.out.println("apply  write query is  "+pstmt3);
			
		}
		
		catch(SQLException sqle){
			System.out.println("SQL exception when getting coursel. list");
		}
		
		finally {
			
			DBConnection.closeConnection(connection);
			
			
		}
		
		 request.setAttribute("Suser", Suser);	
		 request.setAttribute("company_id", company_id);	
		 
		 request.getRequestDispatcher("/apply.jsp").forward(request, response);
	
	}
	
	
	

	
	

}
