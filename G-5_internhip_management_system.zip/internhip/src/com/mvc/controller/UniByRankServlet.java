package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.UniByRankBean;
import com.mvc.dao.UniByRankDao;

public class UniByRankServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UniByRankServlet(){

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		//String Company_id = request.getParameter("rest");
		List<UniByRankBean> universityDetailList = new ArrayList<>();
    	universityDetailList = UniByRankDao.getUniversityByRank();//check
		List<String> university_idList = new ArrayList<>();
		List<String> university_nameList = new ArrayList<>();
		List<String> university_typeList = new ArrayList<>();
		List<Integer> university_rankList = new ArrayList<>();
		List<String> emailList = new ArrayList<>();
		List<Integer> location_pinList = new ArrayList<>();
		System.out.println("in ubr serv  "+universityDetailList);
		System.out.println("in ubr serv  "+universityDetailList.get(0));
		//List<String> projectidList = new ArrayList<>();
		for(int i=0;i<universityDetailList.size();i++){
			String s1 =universityDetailList.get(i).getUniId();
			university_idList.add(s1);
			String s2 =universityDetailList.get(i).getUniName();
			 university_nameList.add(s2);
			String s3 =universityDetailList.get(i).getType();
			university_typeList.add(s3);
			int s4 =universityDetailList.get(i).getUniRank();
			university_rankList .add(s4);
			String s5 =universityDetailList.get(i).getEmail();
			emailList.add(s5);
			int s6 =universityDetailList.get(i).getLocationPin();
			location_pinList .add(s6);
		}
		System.out.println("in ubr serv pin  "+location_pinList);
		System.out.println("in ubr serv rank  "+university_rankList);

		request.setAttribute("university_idList", university_idList);
		request.setAttribute("university_nameList",university_nameList);
		request.setAttribute("university_typeList", university_typeList);
		request.setAttribute("university_rankList", university_rankList );
		request.setAttribute("emailList", emailList);
		request.setAttribute("location_pinList", location_pinList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("UniByRank.jsp");
		dispatcher.forward(request, response);

	}
}
