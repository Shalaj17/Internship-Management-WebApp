package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CompanyDetails;
import com.mvc.controller.*;

public class ListCompanies extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ListCompanies() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String Suser = request.getParameter("Suser");
		
		List<CompanyDetails> companyDetailList = new ArrayList<>();
		
		
		companyDetailList = com.mvc.controller.Get.getCompanies();

		System.out.println("companyDetailList: "+companyDetailList);
		
//		locality = "\"" + locality + "\"";
		
		List<String> company_idList = new ArrayList<>();
		List<String>  company_nameList= new ArrayList<>();
		List<String> company_emailList = new ArrayList<>();
		List<String> company_phoneList = new ArrayList<>();
		List<String> company_locationpinList = new ArrayList<>();
		
		for(int i=0;i<companyDetailList.size();i++){
			
//			
			String s5 =companyDetailList.get(i).getcompanyId();
			company_idList.add(s5);
			
			String s2 =companyDetailList.get(i).getcompanyName();
			company_nameList.add(s2);
			
			String s3 =companyDetailList.get(i).getcompanyEmail();
			company_emailList.add(s3);
		
			String s4 =companyDetailList.get(i).getcompanyPhone();
			company_phoneList.add(s4);
			
			String s1 =companyDetailList.get(i).getcompanyLocationpin();

			company_locationpinList.add(s1);
			
	
			}
	
		request.setAttribute("Suser", Suser);
		request.setAttribute("company_idList", company_idList);
		request.setAttribute("company_nameList", company_nameList);
		request.setAttribute("company_emailList", company_emailList);
		request.setAttribute("company_phoneList", company_phoneList);
		request.setAttribute("company_locationpinList", company_locationpinList);

		
		RequestDispatcher dispatcher = request.getRequestDispatcher("CompaniesList.jsp");
		dispatcher.forward(request, response);
		
	
	}
	


	
	
}
