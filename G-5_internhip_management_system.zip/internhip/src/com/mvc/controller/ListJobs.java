package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CompanyDetails;
import com.mvc.bean.JobDetails;
import com.mvc.controller.*;


public class ListJobs extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public ListJobs() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String Company_id = request.getParameter("id");
		String Suser = request.getParameter("Suser");
		
		List<JobDetails> jobDetailList = new ArrayList<>();
		
		System.out.println("company_id in (Listjobs.java) "+ Company_id);
		
		
		jobDetailList = com.mvc.controller.Get.getJobs(Company_id);

		System.out.println("jobDetailList: "+jobDetailList);
		
//		locality = "\"" + locality + "\"";
		
		List<String> job_idList = new ArrayList<>();
		List<String>  job_profileList= new ArrayList<>();
		List<String> job_durationList = new ArrayList<>();
		List<String> job_stipendList = new ArrayList<>();
//		List<String> job_locationpinList = new ArrayList<>();
		
		for(int i=0;i<jobDetailList.size();i++){
			
//			
			String s5 =jobDetailList.get(i).getjobId();
			job_idList.add(s5);
			
			String s2 =jobDetailList.get(i).getjobProfile();
			job_profileList.add(s2);
			
			String s3 =jobDetailList.get(i).getjobDuration();
			job_durationList.add(s3);
		
			String s4 =jobDetailList.get(i).getjobStipend();
			job_stipendList.add(s4);
			
			//String s1 =jobDetailList.get(i).getcompanyLocationpin();

			//job_locationpinList.add(s1);
			
	
			}
		
		request.setAttribute("Suser", Suser);
		request.setAttribute("Company_id", Company_id);
		request.setAttribute("job_idList", job_idList);
		request.setAttribute("job_profileList", job_profileList);
		request.setAttribute("job_durationList", job_durationList);
		request.setAttribute("job_stipendList", job_stipendList);
		//request.setAttribute("company_locationpinList", company_locationpinList);
      //  System.out.println("before dispatcher");
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("JobList.jsp");
		dispatcher.forward(request, response);
		
	
	}
	

	
	

}
