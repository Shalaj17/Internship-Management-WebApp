package com.mvc.controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class myprofileServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public myprofileServlet() {} //Initialization

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String id = request.getParameter("Suser");
		System.out.println("user in (myprofileservlet)  "+id);
		
		//String id;
		String name = null;
		String university_id = null;
		String dept = null;
		String ac_year = null;
		String email = null;
		String phone = null;
		String pincode = null;
		
		
	//	String company_id = request.getParameter("company_id");
		//System.out.println("Cuer in (applyservlet)  "+company_id);
		
		Connection connection=null;
		
		try {
			
			connection = DBConnection.createConnection();
			
			PreparedStatement pstmt2= connection.prepareStatement("select student_name from student where student_id=?");
			pstmt2.setString(1, id);
			ResultSet rs2= pstmt2.executeQuery();

			while (rs2.next()){
				
				name = (rs2.getString(1));
			}
			
			PreparedStatement pstmt3= connection.prepareStatement("select university_id from student where student_id=?");
			pstmt3.setString(1, id);
			ResultSet rs3= pstmt3.executeQuery();

			while (rs3.next()){
				
				university_id = (rs3.getString(1));
			}
			
			
			PreparedStatement pstmt4= connection.prepareStatement("select dept_name from student where student_id=?");
			pstmt4.setString(1, id);
			ResultSet rs4= pstmt4.executeQuery();

			while (rs4.next()){
				
				dept = (rs4.getString(1));
			}
			
			PreparedStatement pstmt5= connection.prepareStatement("select academic_year from student where student_id=?");
			pstmt5.setString(1, id);
			ResultSet rs5= pstmt5.executeQuery();

			while (rs5.next()){
				
				ac_year = (rs5.getString(1));
			}
			
			PreparedStatement pstmt6= connection.prepareStatement("select email from student where student_id=?");
			pstmt6.setString(1, id);
			ResultSet rs6= pstmt6.executeQuery();

			while (rs6.next()){
				
				email = (rs6.getString(1));
			}
			
			
			PreparedStatement pstmt7= connection.prepareStatement("select phone_no from student where student_id=?");
			pstmt7.setString(1, id);
			ResultSet rs7= pstmt7.executeQuery();

			while (rs7.next()){
				
				phone = (rs7.getString(1));
			}
			
			
			PreparedStatement pstmt8= connection.prepareStatement("select location_pin from student where student_id=?");
			pstmt8.setString(1, id);
			ResultSet rs8= pstmt8.executeQuery();

			while (rs8.next()){
				
				pincode = (rs8.getString(1));
			}
			
			
			
			
			
		}
		
		catch(SQLException sqle){
			System.out.println("SQL exception when getting coursel. list");
		}
		
		finally {
			
			DBConnection.closeConnection(connection);
			
			
		}
		
		/*
		 * System.out.println(id); System.out.println(name);
		 * System.out.println(university_id); System.out.println(dept);
		 * System.out.println(ac_year); System.out.println(email);
		 * System.out.println(phone); System.out.println(pincode);
		 */
		
		 request.setAttribute("id", id);	
		 request.setAttribute("name", name);	
		 request.setAttribute("university_id", university_id);	
		 request.setAttribute("dept", dept);	
		 request.setAttribute("ac_year", ac_year);	
		 request.setAttribute("email", email);	
		 request.setAttribute("phone", phone);	
		 request.setAttribute("pincode", pincode);	
		// request.setAttribute("id", id);	
		 
		
		 
		 request.getRequestDispatcher("/myprofile.jsp").forward(request, response);
	
	}
	
	
	

	
	

}
