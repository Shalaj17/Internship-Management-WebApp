package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.UniLocBean;
import com.mvc.dao.UniLockDao;

public class UniLockServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UniLockServlet(){

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String city = request.getParameter("city");
		List<UniLocBean> universityDetailList = new ArrayList<>();
    	universityDetailList = UniLockDao.getUniLock(city );//check
		List<String> university_idList = new ArrayList<>();
		List<String> university_nameList = new ArrayList<>();
		//List<String> university_typeList = new ArrayList<>();
		//List<Int> university_rankList = new ArrayList<>();
		List<String> emailList = new ArrayList<>();
		//List<Int> location_pinList = new ArrayList<>();
		//List<String> projectidList = new ArrayList<>();
		for(int i=0;i<universityDetailList.size();i++){
			String s1 =universityDetailList.get(i).getUniId();
			university_idList.add(s1);
			String s2 =universityDetailList.get(i).getUniName();
			 university_nameList.add(s2);
			
			
			String s3 =universityDetailList.get(i).getEmail();
			emailList.add(s3);
			
		}

		request.setAttribute("university_idList", university_idList);
		request.setAttribute("university_nameList",university_nameList);
		//request.setAttribute("university_typeList", university_typeList);
		//request.setAttribute("university_rankList ", university_rankList );
		request.setAttribute("emailList", emailList);
		//request.setAttribute("location_pinList", location_pinListt);
		RequestDispatcher dispatcher = request.getRequestDispatcher("UniLock.jsp");
		dispatcher.forward(request, response);

	}
}
