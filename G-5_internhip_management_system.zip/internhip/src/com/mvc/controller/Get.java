package com.mvc.controller;

/*import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;*/


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import com.mvc.util.DBConnection;

import com.mvc.bean.CompanyDetails;
import com.mvc.bean.JobDetails;

public class Get {

	public static List<CompanyDetails> getCompanies() {
		
		List<String> compId = new ArrayList<>();

		List<CompanyDetails> detailList = new ArrayList<>();
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = DBConnection.createConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select distinct company_id from company");
		
			while (resultSet.next()){
				compId.add(resultSet.getString(1));
			}
			

			System.out.println("Company Ids are  " + compId );

			for(int i=0;i<compId.size();i++){

				String id = compId.get(i);
				
				CompanyDetails obj = new CompanyDetails();
				
				obj.setcompanyId(id);
				
				System.out.println("loop is runnning "+ id);
				
				PreparedStatement pstmt2= connection.prepareStatement("select company_name from company where company_id=?");
				pstmt2.setString(1, id);
				ResultSet rs2= pstmt2.executeQuery();

				while (rs2.next()){
					
					obj.setcompanyName(rs2.getString(1));
				//	System.out.println("s1"+rs2.getString(1));
				}
				PreparedStatement pstmt3= connection.prepareStatement("select email from company where company_id=?");
				pstmt3.setString(1, id);
				ResultSet rs3= pstmt3.executeQuery();

				while (rs3.next()){
					obj.setcompanyEmail(rs3.getString(1));
				//	System.out.println("s2"+obj.getRating());

				}

				PreparedStatement pstmt4= connection.prepareStatement("select phone_no from company where company_id=?");
				pstmt4.setString(1, id);
				ResultSet rs4= pstmt4.executeQuery();

				while (rs4.next()){
					obj.setcompanyPhone(rs4.getString(1));
				//	System.out.println("s3"+obj.getLocation());

				}

				PreparedStatement pstmt5= connection.prepareStatement("select location_pin from company where company_id=?");
				pstmt5.setString(1, id);
				ResultSet rs5= pstmt5.executeQuery();

				while (rs5.next()){
					obj.setcompanyLocationpin(rs5.getString(1));
				}
				
				
				
				//System.out.println(obj);
				detailList.add(obj);
				
			}
			
			//System.out.println(detailList);

		} catch(SQLException sqle){
			System.out.println("SQL exception when getting restaurant details list  in function getRestaurants");
		} finally{
			DBConnection.closeConnection(connection);
		}
		return detailList;

	}
	
	
	
	//get jobs method
	
	public static List<JobDetails> getJobs(String Company_id) {
		
		List<String> pId = new ArrayList<>();

		List<JobDetails> detailList = new ArrayList<>();
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = DBConnection.createConnection();
			//statement = connection.createStatement();
			//resultSet = statement.executeQuery("select project_id from manages where company_id=?");
			
			
	PreparedStatement pstmt1= connection.prepareStatement("select p_id from manages where c_id=?");
			
			pstmt1.setString(1, Company_id);
			ResultSet rs5= pstmt1.executeQuery();
			
		
			while (rs5.next()){
				pId.add(rs5.getString(1));
			}
			

			System.out.println("project  Ids are  " + pId );

			for(int i=0;i<pId.size();i++){

				String id = pId.get(i);
				
				JobDetails obj = new JobDetails();
				
				obj.setjobId(id);
				
				System.out.println("loop is runnning "+ id);
				
				PreparedStatement pstmt2= connection.prepareStatement("select intern_profile from internship where project_id=?");
				pstmt2.setString(1, id);
				ResultSet rs6= pstmt2.executeQuery();

				while (rs6.next()){
					
					obj.setjobProfile(rs6.getString(1));
				}
				PreparedStatement pstmt3= connection.prepareStatement("select duration from internship where project_id=?");
				pstmt3.setString(1, id);
				ResultSet rs7= pstmt3.executeQuery();

				while (rs7.next()){
					obj.setjobDuration(rs7.getString(1));
				}

				PreparedStatement pstmt4= connection.prepareStatement("select stipend from internship where project_id=?");
				pstmt4.setString(1, id);
				ResultSet rs8= pstmt4.executeQuery();

				while (rs8.next()){
					obj.setjobStipend(rs8.getString(1));

				}
				detailList.add(obj);
				
			}
			
			//System.out.println(detailList);

		} catch(SQLException sqle){
			System.out.println("SQL exception when getting restaurant details list  in function getRestaurants");
		} finally{
			DBConnection.closeConnection(connection);
		}
		return detailList;

	}
	
	

	
}
