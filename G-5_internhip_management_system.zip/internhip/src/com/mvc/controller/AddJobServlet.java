package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.AddJobBean;
import com.mvc.dao.AddJobDao;
//@WebServlet("/AddJobServlet")
public class AddJobServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	 public AddJobServlet() {
	 }
	
	protected void doPost (HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException 
	{
		System.out.println("inside the add job servlet");
		
		String project_id = request.getParameter("project_id");
		String intern_profile= request.getParameter("intern_profile");
		String duration= request.getParameter("duration");
		String stipend= request.getParameter("stipend");
	
		AddJobBean addJobBean= new AddJobBean();
		
		addJobBean.setProjectId(project_id);
		addJobBean.setInternProfile(intern_profile);
		addJobBean.setDuration(duration);
		addJobBean.setStipend(stipend);
		
		AddJobDao addJobDao=new AddJobDao();
		
		String addjob=addJobDao.addjob(addJobBean);
		
		if(addjob.equals("SUCCESS"))
		{
			request.setAttribute("project_id", project_id);
			request.getRequestDispatcher("/NewJobAdded.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
		}
		else
		 {
			 System.out.println("not added succdesfully");
		 request.setAttribute("errMessage", addjob);
		 //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
		 request.getRequestDispatcher("/AddJob.jsp").forward(request, response);//forwarding the request
		 }
	}
}
