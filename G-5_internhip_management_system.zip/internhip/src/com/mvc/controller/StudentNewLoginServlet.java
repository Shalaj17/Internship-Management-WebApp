package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.StudentNewLoginBean;
import com.mvc.dao.StudentNewLoginDao;
 

public class StudentNewLoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public StudentNewLoginServlet() {
	 }
	
		
		protected void doPost (HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException 
		{
			 
			//Here username and password are the names which I have given in the input box in Login.jsp page. Here I am retrieving the values entered by the user and keeping in instance variables for further use.
			 
			String userName = request.getParameter("id");
			 String password = request.getParameter("pwd");
			 String name = request.getParameter("name");
			 String university = request.getParameter("university");
			 String department = request.getParameter("Department");
			 String acyear = request.getParameter("year");
			 String email = request.getParameter("Email");
			 String phone = request.getParameter("PhoneNumber");
			 String city = request.getParameter("City");
			 String state = request.getParameter("State");
			 String pincode = request.getParameter("PinCode");
			 
			 
			 
			 
			 System.out.println("pincode is "+pincode);
			 
			StudentNewLoginBean studentNewLoginBean = new StudentNewLoginBean(); //creating object for LoginBean class, which is a normal java class, contains just setters and getters. Bean classes are efficiently used in java to access user information wherever required in the application.
			 
			studentNewLoginBean.setUserName(userName); //setting the username and password through the loginBean object then only you can get it in future.
			studentNewLoginBean.setPassword(password);
			studentNewLoginBean.setName(name);
			studentNewLoginBean.setUniversity(university);
			studentNewLoginBean.setDepartment(department);
			studentNewLoginBean.setAcyear(acyear);
			studentNewLoginBean.setEmail(email);
			studentNewLoginBean.setPhone(phone);
			studentNewLoginBean.setCity(city);
			studentNewLoginBean.setState(state);
			studentNewLoginBean.setPincode(pincode);
			 
			StudentNewLoginDao studentNewLoginDao = new StudentNewLoginDao(); //creating object for LoginDao. This class contains main logic of the application.
			 
			String addsaccount = studentNewLoginDao.addsaccount(studentNewLoginBean); //Calling authenticateUser function
			//studentNewLoginDao.addsaccount(studentNewLoginBean);
			if(addsaccount.equals("SUCCESS")) //If function returns success string then user will be rooted to Home page
			 {
			 request.setAttribute("userName", userName); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
			 request.getRequestDispatcher("/studentnewaccount.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
			 }
			 else
			 {
				 System.out.println("not added succdesfully");
			 request.setAttribute("errMessage", addsaccount);
			 //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
			 request.getRequestDispatcher("/StudSignUp.jsp").forward(request, response);//forwarding the request
			 }
			 }
		
	 

}
