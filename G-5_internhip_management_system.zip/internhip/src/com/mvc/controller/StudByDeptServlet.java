package com.mvc.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.StudByDeptBean;
import com.mvc.dao.StudByDeptDao;

public class StudByDeptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public StudByDeptServlet(){

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		//String Company_id = request.getParameter("rest");
		List<StudByDeptBean> studentDetailList = new ArrayList<>();
    	studentDetailList = StudByDeptDao.getStudByDept();//check
		List<String> student_idList = new ArrayList<>();
		List<String> student_nameList = new ArrayList<>();
		List<String> university_idList = new ArrayList<>();
		List<String> departmentList = new ArrayList<>();
		List<Integer> cpiList = new ArrayList<>();
		//List<Int> location_pinList = new ArrayList<>();
		//List<String> projectidList = new ArrayList<>();
		for(int i=0;i<studentDetailList.size();i++){
			String s1 =studentDetailList.get(i).getId();
			student_idList.add(s1);
			String s2 =studentDetailList.get(i).getName();
			 student_nameList.add(s2);
			String s3 =studentDetailList.get(i).getUniId();
			university_idList.add(s3);
			String s4 =studentDetailList.get(i).getDeptName();
			departmentList .add(s4);
			int s5 =studentDetailList.get(i).getCpi();
			cpiList .add(s5);
			
		}

		request.setAttribute("student_idList", student_idList);
		request.setAttribute("student_nameList",student_nameList);
		request.setAttribute("university_idList", university_idList);
		//request.setAttribute("university_rankList", university_rankList );
		request.setAttribute("departmentList", departmentList );
		request.setAttribute("cpiList", cpiList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("StudByDept.jsp");
		dispatcher.forward(request, response);

	}
	
}
