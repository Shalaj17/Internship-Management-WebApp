package com.mvc.dao;

import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.mvc.bean.StudentNewLoginBean;
import com.mvc.util.DBConnection;
public class StudentNewLoginDao {
	
	String flag="SUCCESS";
	int a;
public String addsaccount(StudentNewLoginBean studentNewLoginBean)
{
	
	
String userName = studentNewLoginBean.getUserName(); //Keeping user entered values in temporary variables.
String password = studentNewLoginBean.getPassword();
String name     = studentNewLoginBean.getName();
String university     = studentNewLoginBean.getUniversity();
String department     = studentNewLoginBean.getDepartment();
String acyear     = studentNewLoginBean.getAcyear();
String email     = studentNewLoginBean.getEmail();
String phone     = studentNewLoginBean.getPhone();
String city     = studentNewLoginBean.getCity();
String state     = studentNewLoginBean.getState();
String pincode     = studentNewLoginBean.getPincode();


Connection con = null;
Statement statement = null;
ResultSet resultSet = null;
		/*
		 * String userNameDB = ""; String passwordDB = "";
		 */
Connection connection=null;

try{
	System.out.println("just agter ygdshds");
	connection = DBConnection.createConnection();
	System.out.println("just agter ygdshds");
	
	
	
	 PreparedStatement pstmt3 = connection.prepareStatement("insert into location values(?,?,?,?)");
	 
	  pstmt3.setInt(1,Integer.parseInt(pincode)); 
	  pstmt3.setString(2, city);
	  pstmt3.setString(3,state);
	  pstmt3.setString(4, "India"); 
	  pstmt3.executeUpdate();
	  System.out.println("s location write query is  "+pstmt3);
	  
	  

	  PreparedStatement pstmt = connection.prepareStatement("insert into student values(?,?,?,?,?,?,?,?)");
	  pstmt.setString(1, userName);
	  System.out.println(userName);
	  pstmt.setString(2, name);
	  System.out.println(name);
	  pstmt.setString(3,university);
	  System.out.println(university);
	  pstmt.setString(4, department); 
	  System.out.println(department);
	  pstmt.setInt(5, Integer.parseInt(acyear));
	  System.out.println(acyear);
	  pstmt.setString(6, email);
	  System.out.println(email);
	  pstmt.setString(7, phone);
	  System.out.println(phone);
	  pstmt.setInt(8,Integer.parseInt(pincode)); 
	  System.out.println(Integer.parseInt(pincode));
	  System.out.println("student write query is  "+pstmt);
	  //System.out.println(id + " " + password );
		//System.out.println("problem just after set string not going exe");
	  pstmt.executeUpdate();
	  
	  
	  
		PreparedStatement pstmt2= connection.prepareStatement("insert into student_login values(?,?)");
		 
		pstmt2.setString(1, userName);
		//System.out.println("problem just after set string not going exe");
		pstmt2.setString(2, password);
		//System.out.println("problem just after set string2 not going exe ");
		pstmt2.executeUpdate();
		//System.out.println("problem just after set executr");
		System.out.println("student_login write query is  "+pstmt2);
		
	  
	  System.out.println("university is" + university);
	  
	 
	
	  
	  PreparedStatement pstmt4 = connection.prepareStatement("insert into studies values(?,?)");

	  pstmt4.setString(1, userName);
	  pstmt4.setString(2,university); 
	  pstmt4.executeUpdate();
	  System.out.println("studies write query is  "+pstmt4);
	  
	  
	  
	
	 

	
} catch(SQLException sqle){
	System.out.println("SQL exception when getting coursel. list");
} 

finally{
	DBConnection.closeConnection(connection);
}

return flag  ;
}
}