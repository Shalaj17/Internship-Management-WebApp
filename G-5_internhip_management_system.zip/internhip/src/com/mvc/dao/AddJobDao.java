package com.mvc.dao;

import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mvc.bean.AddJobBean;
import com.mvc.util.DBConnection;

public class AddJobDao {
	String flag="SUCCESS";
	int a;
	public String addjob(AddJobBean addJobBean)
	{
		String project_id = addJobBean.getProjectId();
		String intern_profile = addJobBean.getInternProfile();
		String duration = addJobBean.getDuration();
		String stipend = addJobBean.getStipend();
		
		Statement statement = null;
		ResultSet resultSet = null;
		Connection connection=null;
		
		try{
			System.out.println("just agter ygdshds");
			connection = DBConnection.createConnection();
			System.out.println("just agter ygdshds");
			
			 PreparedStatement pstmt3 = connection.prepareStatement("insert into internship values(?,?,?,?)");
			 
			  pstmt3.setString(1, project_id); 
			  pstmt3.setString(2, intern_profile);
			  pstmt3.setString(3, duration);
			  pstmt3.setInt(4,Integer.parseInt(stipend)); 
			  pstmt3.executeUpdate();
			  System.out.println("s location write query is  "+pstmt3);
		}
		catch(SQLException sqle){
			System.out.println("SQL exception when getting coursel. list");
		} 
			  return flag;	
	}
}
