package com.mvc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mvc.bean.UniLocBean;
import com.mvc.util.DBConnection;
public class UniLockDao {
	public static  List<UniLocBean> getUniLock(String city)
	{
			
		 List<String> universityId= new ArrayList<>(); 
//		String id=uniByRankBean.getId();
		List<UniLocBean> detailList = new ArrayList<UniLocBean>();
		Connection connection=null;
		try{
			connection=DBConnection.createConnection();
			PreparedStatement pstmt1= connection.prepareStatement("select university.university_id from university,location where location.location_pin = university.location_pin and location.city=?");
			pstmt1.setString(1, city);
			ResultSet rs5= pstmt1.executeQuery();

			while (rs5.next()){
				universityId.add(rs5.getString(1));
			}
			System.out.println(universityId);
		for(int i=0;i<universityId.size();i++){

				String id = universityId.get(i);
				
				UniLocBean obj = new UniLocBean();
				
				obj.setUniId(id);
				
				System.out.println("loop is runnning"+id);
				
				PreparedStatement pstmt2= connection.prepareStatement("select university_name from university where university_id=?");
				pstmt2.setString(1, id);
				ResultSet rs6= pstmt2.executeQuery();

				while (rs6.next()){
					
					obj.setUniName(rs6.getString(1));
				}
		
				PreparedStatement pstmt4= connection.prepareStatement("select university_rank from university where university_id=?");
				pstmt4.setString(1, id);
				ResultSet rs8= pstmt4.executeQuery();

				while (rs8.next()){
					obj.setUniRank(rs8.getInt(1));

				}

				
				PreparedStatement pstmt6= connection.prepareStatement("select email from university where university_id=?");
				pstmt6.setString(1, id);
				ResultSet rs7= pstmt6.executeQuery();

				while (rs7.next()){
					obj.setEmail(rs7.getString(1));

				}

				detailList.add(obj);
				
			}
			
			//System.out.println(detailList);

		} catch(SQLException sqle){
			System.out.println("SQL exception when getting university details list  in  location function getJob");
		} finally{
			DBConnection.closeConnection(connection);
		}
		return detailList;
	}
}
