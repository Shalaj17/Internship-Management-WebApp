package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mvc.bean.UniByRankBean;
import com.mvc.util.DBConnection;

//add project details

public class UniByRankDao {
	public static List<UniByRankBean> getUniversityByRank()
	{
	 //	List<UniByRankBean> universityId = new ArrayList<UniByRankBean>();
		//ArrayList<StudentBean> std = new ArrayList<StudentBean>(); 
		List<UniByRankBean> detailList = new ArrayList<UniByRankBean>();
		List<String> universityId = new ArrayList<>();
		//String id=jobbean.getId();//doubt
		Connection connection=null;
		try{
			connection=DBConnection.createConnection();
			PreparedStatement pstmt1= connection.prepareStatement("select university_id from university order by university_rank");
			
			//pstmt1.setString(1, company_id);
			ResultSet rs5= pstmt1.executeQuery();

			while (rs5.next()){
				universityId.add(rs5.getString(1));
			}

			for(int i=0;i<universityId.size();i++){

				String id = universityId.get(i);
				
				UniByRankBean obj = new UniByRankBean();
				
				obj.setUniId(id);
				
				System.out.println("loop is runnning"+id);
				
				PreparedStatement pstmt2= connection.prepareStatement("select university_name from university where university_id=?");
				pstmt2.setString(1, id);
				ResultSet rs6= pstmt2.executeQuery();

				while (rs6.next()){
					
					obj.setUniName(rs6.getString(1));
				}
				PreparedStatement pstmt3= connection.prepareStatement("select type from university where university_id=?");
				pstmt3.setString(1, id);
				ResultSet rs7= pstmt3.executeQuery();

				while (rs7.next()){
					obj.setType(rs7.getString(1));
				}

				PreparedStatement pstmt4= connection.prepareStatement("select university_rank from university where university_id=?");
				pstmt4.setString(1, id);
				ResultSet rs8= pstmt4.executeQuery();

				while (rs8.next()){
					obj.setUniRank(Integer.parseInt(rs8.getString(1)));

				}

				PreparedStatement pstmt5= connection.prepareStatement("select location_pin from university where university_id=?");
				pstmt5.setString(1, id);
				ResultSet rs9= pstmt5.executeQuery();

				while (rs9.next()){
					obj.setLocationPin(rs9.getInt(1));

				}
				PreparedStatement pstmt6= connection.prepareStatement("select email from university where university_id=?");
				pstmt6.setString(1, id);
				ResultSet rs10= pstmt6.executeQuery();

				while (rs10.next()){
					obj.setEmail(rs10.getString(1));

				}

				detailList.add(obj);
				
			}
			
			//System.out.println(detailList);

		} catch(SQLException sqle){
			System.out.println("SQL exception when getting university details list  in function getJob");
		} finally{
			DBConnection.closeConnection(connection);
		}
		return detailList;
	}
}
			
