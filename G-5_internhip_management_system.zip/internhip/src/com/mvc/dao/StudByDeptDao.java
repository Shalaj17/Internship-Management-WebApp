package com.mvc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mvc.bean.StudByDeptBean;
import com.mvc.bean.UniByRankBean;
import com.mvc.util.DBConnection;

public class StudByDeptDao {
	public static List<StudByDeptBean> getStudByDept()
	{
		 //ArrayList<StudByDeptBean> sbd = new ArrayList<StudByDeptBean>(); 
//		String id=uniByRankBean.getId();
		List<StudByDeptBean> detailList = new ArrayList<StudByDeptBean>();
		List<String> studentId = new ArrayList<>();
		Connection connection=null;
		try{
			connection=DBConnection.createConnection();
			PreparedStatement pstmt1= connection.prepareStatement("select student_id,dept_name from student  order by dept_name, cpi desc");
			
			//pstmt1.setString(1, company_id);
			ResultSet rs5= pstmt1.executeQuery();

			while (rs5.next()){
				studentId.add(rs5.getString(1));
			}
			for(int i=0;i<studentId.size();i++){

				String id = studentId.get(i);
				
				StudByDeptBean obj = new StudByDeptBean();
				
				obj.setId(id);
				
				System.out.println("loop is runnning"+id);
				
				PreparedStatement pstmt2= connection.prepareStatement("select student_name from student where student_id=?");
				pstmt2.setString(1, id);
				ResultSet rs6= pstmt2.executeQuery();

				while (rs6.next()){
					
					obj.setName(rs6.getString(1));
				}
				PreparedStatement pstmt3= connection.prepareStatement("select university_id from student where student_id=?");
				pstmt3.setString(1, id);
				ResultSet rs7= pstmt3.executeQuery();

				while (rs7.next()){
					obj.setUniId(rs7.getString(1));
				}

				PreparedStatement pstmt4= connection.prepareStatement("select dept_name from student where student_id=?");
				pstmt4.setString(1, id);
				ResultSet rs8= pstmt4.executeQuery();

				while (rs8.next()){
					obj.setDeptName(rs8.getString(1));

				}

				PreparedStatement pstmt5= connection.prepareStatement("select cpi from student where student_id=?");
				pstmt5.setString(1, id);
				ResultSet rs9= pstmt5.executeQuery();

				while (rs9.next()){
					obj.setCpi(rs9.getInt(1));

				}
				

				detailList.add(obj);
				
			}
			
			//System.out.println(detailList);

		} catch(SQLException sqle){
			System.out.println("SQL exception when getting student details list  by cpi");
		} finally{
			DBConnection.closeConnection(connection);
		}
		return detailList;
	}
}
		
