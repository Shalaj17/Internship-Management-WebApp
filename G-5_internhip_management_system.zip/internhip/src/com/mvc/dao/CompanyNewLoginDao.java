package com.mvc.dao;


import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.mvc.bean.CompanyNewLoginBean;
import com.mvc.util.DBConnection;

public class CompanyNewLoginDao {
	
	String flag="SUCCESS";
	int a;
public String addcaccount(CompanyNewLoginBean companyNewLoginBean)
{
	
	
String userName = companyNewLoginBean.getUserName(); //Keeping user entered values in temporary variables.
String password = companyNewLoginBean.getPassword();
String name     = companyNewLoginBean.getName();
String email     = companyNewLoginBean.getEmail();
String phone     = companyNewLoginBean.getPhone();
String city     = companyNewLoginBean.getCity();
String state     = companyNewLoginBean.getState();
String pincode     = companyNewLoginBean.getPincode();


//Statement pstmt3 = null;
ResultSet resultSet = null;
		/*
		 * String userNameDB = ""; String passwordDB = "";
		 */
Connection connection=null;

try{
	connection = DBConnection.createConnection();
	
	
	 PreparedStatement pstmt3 = connection.prepareStatement("insert into location values(?,?,?,?)");
	
	  pstmt3.setInt(1,Integer.parseInt(pincode)); 
	  pstmt3.setString(2, city);
	  pstmt3.setString(3,state);
	  pstmt3.setString(4, "India"); 
	  pstmt3.executeUpdate();
	 
	  
	  System.out.println("clocation after write query is  "+pstmt3);
	  
	  
	  PreparedStatement pstmt = connection.prepareStatement("insert into company values(?,?,?,?,?)");
	  pstmt.setString(1, userName);
	  pstmt.setString(2, name);
	  pstmt.setString(3, email);
	  pstmt.setString(4, phone);
	  pstmt.setInt(5,Integer.parseInt(pincode)); 
	  
	  System.out.println(Integer.parseInt(pincode));
	  System.out.println("company write query is  "+pstmt);
	  //System.out.println(id + " " + password );
		//System.out.println("problem just after set string not going exe");
	  pstmt.executeUpdate();
	  
	  
	PreparedStatement pstmt2= connection.prepareStatement("insert into company_login values(?,?)");
	System.out.println(userName+"  "+password);
	pstmt2.setString(1, userName);
	//System.out.println("problem just after set string not going exe");
	pstmt2.setString(2, password);
	//System.out.println("problem just after set string2 not going exe ");
	pstmt2.executeUpdate();
	//System.out.println("problem just after set executr");
	 System.out.println("companylogin after write query is  "+pstmt2);
	
	
	  
	  
	  
	
	  
	
	 


	
} catch(SQLException sqle){
	System.out.println("SQL exception when getting coursel. list");
} 

finally{
	DBConnection.closeConnection(connection);
}

return flag  ;
}
}