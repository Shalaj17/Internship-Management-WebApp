package com.mvc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

 
public class DBConnection {
	
	public static Connection createConnection() {
		//System.out.println("is it coming here");
		String dbURL = "jdbc:postgresql://localhost:5432/internship";
		String dbUser = "postgres";
		String dbPass = "123456";
		Connection connection=null;
		
		try {
			
			Class.forName("org.postgresql.Driver");
			
			connection = DriverManager.getConnection(dbURL, dbUser, dbPass);
			
		} catch(ClassNotFoundException cnfe){
			System.out.println("JDBC Driver not found");
		} catch(SQLException sqle){
			System.out.println("Error in getting connetcion from the database");
		}
		System.out.println("database connection established");
		return connection;
		
	}

public	static void closeConnection(Connection connection) {
		try{
			connection.close();
		} catch(SQLException sqle) {
			System.out.println("Error in close database connetcion");
		}
	}
	
	
public static void AddStuAccount(String id,String password,String name,String university,String department,String year,String email,String phoneno,String city,String state,String pincode){
		
		Connection connection=null;
		
		try{
			System.out.println("is it coming start here");
			connection=createConnection();
			
			System.out.println("is it coming accounts here");
			

		
			PreparedStatement pstmt2= connection.prepareStatement("insert into student_login values(?,?)");
			  
			pstmt2.setString(1, id);
			//System.out.println("problem just after set string not going exe");
			pstmt2.setString(2, password);
			//System.out.println("problem just after set string2 not going exe ");
			pstmt2.executeUpdate();
			//System.out.println("problem just after set executr");
		
			
			
			
			  PreparedStatement pstmt = connection.prepareStatement("insert into student values(?,?,?,?,?,?,?,?)");
			  pstmt.setString(1, id);
			  pstmt.setString(2, name);
			  pstmt.setString(3,university);
			  pstmt.setString(4, department); 
			  pstmt.setInt(5, Integer.parseInt(year));
			  pstmt.setString(6, email);
			  pstmt.setString(7, phoneno);
			  pstmt.setInt(8,Integer.parseInt(pincode)); 
			  //System.out.println(id + " " + password );
				//System.out.println("problem just after set string not going exe");
			  pstmt.executeUpdate();
			  
			
			 
		
		
			
		} catch(SQLException sqle){
			System.out.println("SQL exception when getting coursel. list");
		} finally{
			closeConnection(connection);
		}
		
		return;
	}
	
	
public static void AddCompAccount(String id,String password,String companyname,String email,String phoneno,String city,String state,String pincode){
	
	Connection connection=null;
	
	try{
		connection=createConnection();
		

	
		PreparedStatement pstmt2= connection.prepareStatement("insert into company_login values(?,?)");
		  
		pstmt2.setString(1, id);
		//System.out.println("problem just after set string not going exe");
		pstmt2.setString(2, password);
		//System.out.println("problem just after set string2 not going exe ");
		pstmt2.executeUpdate();
		//System.out.println("problem just after set executr");
	
		
		
		
		  PreparedStatement pstmt = connection.prepareStatement("insert into student values(?,?,?,?,?)");
		  pstmt.setString(1, id);
		  pstmt.setString(2, companyname);
		  pstmt.setString(3,email);
		  pstmt.setString(4, phoneno); 
		  pstmt.setInt(5, Integer.parseInt(pincode));
	
		  //System.out.println(id + " " + password );
			//System.out.println("problem just after set string not going exe");
		  pstmt.executeUpdate();
		  
		
		 
	
	
		
	} catch(SQLException sqle){
		System.out.println("SQL exception when getting coursel. list");
	} finally{
		closeConnection(connection);
	}
	
	return;
}


public static List<String> getuniversities(){

	List<String> citylist = new ArrayList<String>();

	Connection connection=null;

	try{
		connection=createConnection();
		PreparedStatement pstmt= connection.prepareStatement("select distinct university_id from university order by university_id asc");
		ResultSet rs= pstmt.executeQuery();
		while (rs.next()){
			citylist.add(rs.getString(1));
		}

	} catch(SQLException sqle){
		System.out.println("SQL exception when getting universities  in function getuniversities");
	} finally{
		closeConnection(connection);
	}


	return citylist;

}


public static List<String> getcities(){

	List<String> citylist = new ArrayList<String>();

	Connection connection=null;

	try{
		connection=createConnection();
		PreparedStatement pstmt= connection.prepareStatement("select distinct city from location order by city asc");
		ResultSet rs= pstmt.executeQuery();
		while (rs.next()){
			citylist.add(rs.getString(1));
		}

	} catch(SQLException sqle){
		System.out.println("SQL exception when getting cities  in function getcities");
	} finally{
		closeConnection(connection);
	}


	return citylist;

}

	/*
	 * public static Connection createConnection() { Connection con = null; String
	 * url = "jdbc:postgresql://localhost:5432/internship_management"; //MySQL URL
	 * and followed by the database name String username = "postgres"; //MySQL
	 * username String password = "123456"; //MySQL password
	 * 
	 * try { try { Class.forName("org.postgresql.Driver"); } catch
	 * (ClassNotFoundException e) { e.printStackTrace(); } con =
	 * DriverManager.getConnection(url, username, password); //attempting to connect
	 * to MySQL database System.out.println("Printing connection object "+con); }
	 * catch (Exception e) { e.printStackTrace(); } return con; }
	 */
}
